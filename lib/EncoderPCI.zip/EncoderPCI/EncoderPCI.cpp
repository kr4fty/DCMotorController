#include "EncoderPCI.h"

static Encoder_internal_state_t * Encoder::interruptArgs[];
